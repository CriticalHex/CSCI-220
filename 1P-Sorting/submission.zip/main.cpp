/*
 * main.cpp
 *
 * Includes the main() function for the sorting project.
 *
 * This code is included in the build target "run-main"
 */

#include <cstddef>
#include <iostream>
#include <vector>

#include "sorter.h"

using namespace std;

int main() {
  // You can use this main() to run your own analysis or testing code.
  cout << "If you are seeing this, you have successfully run main!" << endl;
  vector<int> toSort = {10, 12, 2, 17, -4, 0, -9, 31, 6, 11};
  //   random_shuffle(toSort.begin(), toSort.end());
  //   for (auto k : toSort) {
  //     cout << k << ", ";
  //   }
  //   cout << endl;
  sorter(toSort, 2);

  return 0;
}
